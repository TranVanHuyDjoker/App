package com.example.app.services.EmployeeServiceImpl;

import com.example.app.entities.Employee;
import com.example.app.services.EmployeeService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {
    @Override
    public List<Employee> getAllEmployee() {
        return null;
    }

    @Override
    public Employee addEmployee(Employee employee) {
        return null;
    }

    @Override
    public Employee updateEmployee(Long id) {
        return null;
    }

    @Override
    public void deleteEmployee(Long id) {

    }

    @Override
    public void PaginationEmployee() {

    }

    @Override
    public void sortingEmployee() {

    }

    @Override
    public void searchEmployee() {

    }
}
