package com.example.app.entities;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "Emp")
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    @Column(name = "full_name")
    String fullName;

    @Column(name = "pwd")
    String password;

    @Column(name = "email")
    String email;

    @Column(name = "address")
    String address;


}