package com.example.app.services;

import com.example.app.entities.Employee;

import java.util.List;

public interface EmployeeService {

    List<Employee> getAllEmployee();

    Employee addEmployee(Employee employee);

    Employee updateEmployee(Long id);

    void deleteEmployee(Long id);

    void PaginationEmployee();

    void sortingEmployee();

    void searchEmployee();

}
